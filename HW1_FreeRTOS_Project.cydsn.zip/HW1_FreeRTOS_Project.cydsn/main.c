/* ========================================
 * HW#1 
 * PROGRAM : FREERTOS RTC, THERMISTOR LCD INTERFACE
 * 
 * Copyright Jorge Vicente, 2020
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF JORGE VICENTE.
 *
 * ========================================
*/
//Questions to Ask
//Check code --> tell results print only HW1:FreeRTOS
//Update time
//if we need &taskhandle in our taskcreate
//pdMS delay time difference # vs portmaxDelay

#include "project.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>

#include "FreeRTOS_PSoC.h"
#include "FreeRTOS.h"
#include "task.h"               //task handler library
#include "message_buffer.h"     //Message buffer
#include "queue.h"              //Queue

//1. Initialize your Handles*********************************
//----Message Buffer = Temperature---------- 
MessageBufferHandle_t xMessageBuffer;
const size_t xMessageBufferSizeBytes = 100;
//----Queue = RTC Digital Clock------------- 
QueueHandle_t       xQueueSensor;
/*Define the queue parameters*/
#define QUEUE_LENGTH    5
#define QUEUE_ITEM_SIZE     sizeof(SENSORDATA)

//-----DataStructure----------
typedef struct SENSORDATA{
    uint8_t     sec;
    uint8_t     min;
    uint8_t     hr;  
    bool        pm;
    uint8_t     dow; //dayoftheweek
    uint8_t     month;
    uint16_t    year;
    uint8_t     date;
}SENSORDATA;

//2. Call Your Task Functions created below at end of code ***************************************
void vApp1Task(void *pvParameter);  //RTC Module
void vApp2Task(void *pvParameter);  //Thermistor
void vApp3Task(void *pvParameter);  //Checks state of nSW2


//RTC Address Definition 
#define _DS3231_ADDR        0x68
#define _DS3231_REG_SECONDS 0x00
#define _DS3231_REG_CONTROL 0x0E
#define _DS3231_REG_STATUS  0x0F

#define BCD2DEC(bcd) (((bcd)>>4)*10 + ((bcd)& 0x0F))
//I2C Definitions
#define _I2C_READ   1
#define _I2C_WRITE  0
//Thermistor Definitions
#define ADCMAX      4096.0
#define DEG_SYMB    223
//Call of other Functions 
void MyPSoCSetup();
bool I2CRead(uint8_t addr,uint8_t reg, uint8_t len, uint8_t *buf);  //Read one Byte(Address, Access Register, #Byte2Read/Write , data size)
bool I2CWrite(uint8_t addr,uint8_t reg, uint8_t len, uint8_t *buf); 

//MAIN CODE ONLY HAS RTOS RELATED FUNCTIONS
int main(void)
{    
    
    MyPSoCSetup();   //Place all PSoC Component setup inside this function
//3. Initialize RTOS Data Type     
    BaseType_t err;
    CyGlobalIntEnable; /* Enable global interrupts. */
    FreeRTOS_Init();
    LCD_Position(0,0);
    LCD_PrintString("RTOS Initialized");
   
    LCD_ClearDisplay();
/* 4. Create and Assign Handles Here --------------------------------------------------------------------------------------------------------------------- */
    xMessageBuffer = xMessageBufferCreate(xMessageBufferSizeBytes);
    if(xMessageBuffer == NULL){
        LCD_ClearDisplay();
        LCD_Position(0,0);
		LCD_PrintString("Can't Create Message Buffer");
    }
    
    xQueueSensor =  xQueueCreate(QUEUE_LENGTH, QUEUE_ITEM_SIZE);
    if(xQueueSensor == NULL){
        LCD_ClearDisplay();
        LCD_Position(1,0);
        LCD_PrintString("Can't create Queue Buffer");
        while(1);
    }
//5. Create all Tasks Here ----------------------------------------------------------------------------------------------------------------
//-----TASK 1: RTC Digital Clock ---------------
         err = xTaskCreate(vApp1Task,               //Point to the function that implement the taks
                      "App1",                       // a text name, for debug only
                       configMINIMAL_STACK_SIZE,    // Use Minimal Memory 
                       NULL,                        //Task parameter
                       5,                           //Task Priority
                       NULL);                       //Task Handle
    
    if(err != pdPASS){
        LCD_ClearDisplay();
        LCD_Position(1,0);
        LCD_PrintString("Cannot create task1!");
        while(1);
     }
//---Task 2: Temperature ADC --------------------
     err = xTaskCreate(vApp2Task,                   //Point to the function that implement the taks
                      "App2",                       // a text name, for debug only
                       configMINIMAL_STACK_SIZE,    //Use minimal memory 
                       NULL,                        //Task parameter
                       5,                           //Task Priority
                       NULL);                       //Task Handle
    if(err != pdPASS){
        LCD_ClearDisplay();
        LCD_Position(1,0);
        LCD_PrintString("Cannot create task2!");
        while(1);
        
        
    }
//-----TASK 3: Read Data from Queue and Message Buffer
     err = xTaskCreate(vApp3Task,                   //Point to the function that implement the taks
                      "App3",                       // a text name, for debug only
                       configMINIMAL_STACK_SIZE,    //Use minimal Memory 
                       NULL,                        //Task parameter
                       5,                           //Task Priority
                       NULL);                       //Task Handle
    
    if(err != pdPASS){
        LCD_ClearDisplay();
        LCD_Position(1,0);
        LCD_PrintString("Cannot create task3!");
        while(1);
     }
//------------>  Ask if the bottom is true  
//6. Start the RTOS scheduler running (Only tasks and Interrupt will ever execute-----------------------------------------------------------------------
    LCD_Position(0,0);
    LCD_PrintString("TASK ALMOST COMPLETE");
    vTaskStartScheduler();
    LCD_Position(0,0);
    LCD_PrintString("RTOS ERROR!!");
    
    for(;;){} //No Function in here 
}




//--PSoC Setup Fucntion for All Top Design Components--------------------------------------------------------------------------------------------
void MyPSoCSetup(){
        
        I2C_Start();        //RTC Digital Clock 
        
       // UART_Start();       //For Troubleshooting
        
        ADC_Start();        //Thermistor
        ADC_StartConvert(); //Start conversion for Thermistor
       
        LCD_Start();        //Character Display 
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("HW1:FreeRTOS");
        CyDelay(2000);  //Delay of 2sec, still use CyDelay
        
}
//----TASK 1: RTC Digital Clock ----------------------------------
void vApp1Task(void *pvParameter){
   
    uint8_t     buf[7];
    uint8_t     sec, min, hr, dow, date, month;
    uint16_t    year;
    bool        pm;
    BaseType_t  err;
    SENSORDATA  RTC;
    
    
    if(I2CRead(_DS3231_ADDR, _DS3231_REG_CONTROL, 1, buf)){
        if(buf[0] & 0b10000000){    //check bit 7 (/EOSC)
           buf[0] &= ~0b10000000;  //clear bit 7 to 0
           I2CWrite(_DS3231_ADDR, _DS3231_REG_CONTROL, 1, buf);
        }
    }
        /* Place your application code here. */
    if(I2CRead(_DS3231_ADDR, _DS3231_REG_STATUS, 1, buf)){
        if(buf[0] & 0b1000000){    //Check bit 7 (OSF)
            // You have to set bit7(OSF) to 0 in the Status Register
            buf[0] &= ~0b1000000;
            // Then write it back to the Status Register
            I2CWrite(_DS3231_ADDR, _DS3231_REG_STATUS, 1, buf);
        }
        //Set Deafault Date/Time
        //9:36  4/3/2020    Fri
        buf[0] = 0x00;  //seconds
        buf[1] = 0x13;  //minutes
        buf[2] = 0x22;  //Hour
        buf[3] = 0x07;  //dow
        buf[4] = 0x04;  //Date
        buf[5] = 0x04;  //Month
        buf[6] = 0x20;  //year
        I2CWrite(_DS3231_ADDR, _DS3231_REG_SECONDS, 7, buf); // Set default Date/Time
    }
        
        
      
    
    for(;;)
    {
         // decode all date/time from buf[0] ~ buf[7]
            sec     = BCD2DEC(buf[0]);
            min     = BCD2DEC(buf[1]);
            //hr      = BCD2DEC(buf[2]);
            date    = BCD2DEC(buf[4]);
            month   = BCD2DEC(buf[5]);
            year    = BCD2DEC(buf[6])+2000;
            dow     = BCD2DEC(buf[3]); // check datasheet <---  Fix
        //AM or PM CHECK?
        if(I2CRead(_DS3231_ADDR, _DS3231_REG_SECONDS, 7, buf)){
            // Our system only supports 12 hr format
            if(buf[2] &0b01000000){ //01000000
                //12 hour format   
                pm = buf[2] &0x20;
                hr = (buf[2] &0x1F);
            } else{
                //24 hour format
                hr = BCD2DEC(buf[2] &0x3F);
                if(hr >= 12){
                    pm = true;
                     if(hr > 12) 
                        hr = hr - 12;
                } else{
                    pm = false;
                }
            }         
            // put all information to the struct
            RTC.sec   = sec;
            RTC.min   = min;
            RTC.hr    = hr;// this hr is 12-hr format
            RTC.pm    = pm;
            RTC.dow   = dow;
            RTC.date  = date;
            RTC.month = month;
            RTC.year  = year;
            
             // send it to the queue
            err = xQueueSend(xQueueSensor, &RTC, 0);
            vTaskDelay(pdMS_TO_TICKS(10));  //Delay by 10 seconds
        }
    }
      vTaskDelay(pdMS_TO_TICKS(1000)); //Delay for 1sec
}
//----TASK 2: Temperature ADC--------------------------------------------------------------------------------------------------------------------
//Check if current state is C or F
typedef enum UNITS{
    DEGREE_C,
    DEGREE_F
} UNITS;
void vApp2Task(void *pvParameter){
   
    char str[40];
    uint16_t adc;
    bool swState;
    bool swPreState = true;
    float tempK, tempC , tempF;
    UNITS unit = DEGREE_C;
        
    while(1){
        //Read temperature from sensor
        if(ADC_IsEndConversion(ADC_RETURN_STATUS)){
            adc = ADC_GetResult16();
            //look at pic-->linker --> add lib (m;)
            tempK =log(10000.0 * ((ADCMAX / adc -1)));
            tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK );       //  Temp Kelvin 
            tempC = tempK - 273.15;            // Convert Kelvin to Celcius 
            tempF = (tempC*(9.0/5.0)) + 32.0;
        //}
        // Using (1) state machine  or (2) Software edge detection
        // to check the switch state and change the unit
        //If Sw1 is pressed switch from C to F
        // http://www.airsupplylab.com/embedded/122-input-signal-edge-detection-using-software.html
        swState = nSW1_Read();
        
        if(swPreState && !swState){
            //if F change to C
            if(unit == DEGREE_F)
                unit = DEGREE_C;
            else
                //otherwise current is C change to F
                unit = DEGREE_F;
            //vTaskDelay(pdMS_TO_TICKS(20));
        }

        swPreState = swState;
        
        if(unit == DEGREE_C){
            sprintf(str, "TEMP: %0.2f%cC ", tempC, DEG_SYMB );
        }
        else{
            sprintf(str, "TEMP: %0.2f%cF ", tempF,DEG_SYMB );
        }
    }
        xMessageBufferSend(xMessageBuffer, str, strlen(str)+1, 0); //portMAX_DELAY);
      
      vTaskDelay(pdMS_TO_TICKS(500)); //Delay for 500 ms
    }
}
//----TASK 3: Read Data from Queue and Message Buffer--------------------------------------------------------------------------------------------
//Check to see if its displaying Temperature or DATE/Time
typedef enum CHKDI{
    DISP_TEMP,
    DISP_DATE
}CHKDI;
void vApp3Task(void *pvParameter){
    size_t len;         //Message Buffer Use
    char str[40];       //Message and Queue Use
    BaseType_t err;     //Queue Use
    SENSORDATA RTC;    //Queue Use
    char    *dayWeek[] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"}; // move to task 3
    
    //DISPLAY CHECKING STATE OF SW2
    bool preSW = true;
    bool curSW;
    CHKDI display = DISP_DATE;
    
    while(1){
        // Using (1) state machine  or (2) Software edge detection
        // to check the switch state and change the unit
        curSW = nSW2_Read();
        //If Sw2 is pressed switch to from DISP_TMP to DISP_DATE
        if(preSW && (!curSW)){
            if(display == DISP_TEMP)
                display = DISP_DATE;
            
            else
                display = DISP_TEMP;
        }   
        preSW = curSW;
        //display = DISP_TEMP;
        //Read data buffer before condition
        len = xMessageBufferReceive(xMessageBuffer, str,sizeof(str), 0); //pdMS_TO_TICKS(10));
        err = xQueueReceive(xQueueSensor, &RTC, pdMS_TO_TICKS(10));
        
        if(display == DISP_TEMP){
            if(len != 0){   // if len not equal to 0, and the display is DISP_TMP
                LCD_ClearDisplay();
                LCD_Position(0,0);//print temp
                LCD_PrintString(str);
                
            }
        }else{
            display = DISP_DATE;
            // Read from the queue
            // if you get data from queue and the display is DISP_DATE
            //SEND TO TASK3 
            // Print current date time on the LCD screen
            LCD_ClearDisplay();
            sprintf(str, "%d/%d/%d  ", RTC.month, RTC.date, RTC.year);
            LCD_Position(0,0);
            LCD_PrintString(str);
            sprintf(str, "%d:%d:%d  ", RTC.hr, RTC.min, RTC.sec);
            LCD_Position(1,0);
            LCD_PrintString(str);           
            
            //Print am or pm
            if(RTC.pm)
                LCD_PrintString("PM");
            else
                LCD_PrintString("AM");
            
            sprintf(str, "%s ", dayWeek[RTC.dow - 1]);      // We have to subtract by one because array starts from zero
            LCD_Position(0, 12); 
            LCD_PrintString(str);           
        }
        vTaskDelay(pdMS_TO_TICKS(150));
    }
}



//---------I2C Read and Write Functions----------------------------
bool I2CRead(uint8_t addr,uint8_t reg, uint8_t len, uint8_t *buf) 
{
        uint8_t err;
        uint8_t i;
        bool retVal = false;
    
       
        err = I2C_MasterSendStart(addr, _I2C_WRITE); 
         if(err != I2C_MSTR_NO_ERROR) goto I2CREAD_ERROR;
        err = I2C_MasterWriteByte(reg);
         if(err != I2C_MSTR_NO_ERROR) goto I2CREAD_ERROR;
        err = I2C_MasterSendRestart(addr, _I2C_READ);
         if(err != I2C_MSTR_NO_ERROR) goto I2CREAD_ERROR;
        for(i=0; i<len; i++){
            if(i == (len-1))
               *(buf + i) = I2C_MasterReadByte(I2C_NAK_DATA);
            else
             *(buf + i) = I2C_MasterReadByte(I2C_ACK_DATA);
        }
        retVal = true;
        
    I2CREAD_ERROR:
    I2C_MasterSendStop();
        
    return retVal;
            
            
}
//-----------------------------------------------------------------
bool I2CWrite(uint8_t addr,uint8_t reg, uint8_t len, uint8_t *buf) 
{
    uint8_t err;
    uint8_t i;
    bool retVal = false;
    
        //
    err = I2C_MasterSendStart(addr, _I2C_WRITE); 
        if(err != I2C_MSTR_NO_ERROR) goto I2CWRITE_ERROR;
    err = I2C_MasterWriteByte(reg);
        if(err != I2C_MSTR_NO_ERROR) goto I2CWRITE_ERROR;
        
    for(i=0; i<len; i++){
        err = I2C_MasterWriteByte( *(buf + i));
        if (err != I2C_MSTR_NO_ERROR) goto I2CWRITE_ERROR;
    }
    retVal = true; 
    
    I2CWRITE_ERROR:
    I2C_MasterSendStop();
    return retVal;
}


/* [] END OF FILE */
