/*******************************************************************************
* File Name: V_Res.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_V_Res_H) /* Pins V_Res_H */
#define CY_PINS_V_Res_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "V_Res_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 V_Res__PORT == 15 && ((V_Res__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    V_Res_Write(uint8 value);
void    V_Res_SetDriveMode(uint8 mode);
uint8   V_Res_ReadDataReg(void);
uint8   V_Res_Read(void);
void    V_Res_SetInterruptMode(uint16 position, uint16 mode);
uint8   V_Res_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the V_Res_SetDriveMode() function.
     *  @{
     */
        #define V_Res_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define V_Res_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define V_Res_DM_RES_UP          PIN_DM_RES_UP
        #define V_Res_DM_RES_DWN         PIN_DM_RES_DWN
        #define V_Res_DM_OD_LO           PIN_DM_OD_LO
        #define V_Res_DM_OD_HI           PIN_DM_OD_HI
        #define V_Res_DM_STRONG          PIN_DM_STRONG
        #define V_Res_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define V_Res_MASK               V_Res__MASK
#define V_Res_SHIFT              V_Res__SHIFT
#define V_Res_WIDTH              1u

/* Interrupt constants */
#if defined(V_Res__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in V_Res_SetInterruptMode() function.
     *  @{
     */
        #define V_Res_INTR_NONE      (uint16)(0x0000u)
        #define V_Res_INTR_RISING    (uint16)(0x0001u)
        #define V_Res_INTR_FALLING   (uint16)(0x0002u)
        #define V_Res_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define V_Res_INTR_MASK      (0x01u) 
#endif /* (V_Res__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define V_Res_PS                     (* (reg8 *) V_Res__PS)
/* Data Register */
#define V_Res_DR                     (* (reg8 *) V_Res__DR)
/* Port Number */
#define V_Res_PRT_NUM                (* (reg8 *) V_Res__PRT) 
/* Connect to Analog Globals */                                                  
#define V_Res_AG                     (* (reg8 *) V_Res__AG)                       
/* Analog MUX bux enable */
#define V_Res_AMUX                   (* (reg8 *) V_Res__AMUX) 
/* Bidirectional Enable */                                                        
#define V_Res_BIE                    (* (reg8 *) V_Res__BIE)
/* Bit-mask for Aliased Register Access */
#define V_Res_BIT_MASK               (* (reg8 *) V_Res__BIT_MASK)
/* Bypass Enable */
#define V_Res_BYP                    (* (reg8 *) V_Res__BYP)
/* Port wide control signals */                                                   
#define V_Res_CTL                    (* (reg8 *) V_Res__CTL)
/* Drive Modes */
#define V_Res_DM0                    (* (reg8 *) V_Res__DM0) 
#define V_Res_DM1                    (* (reg8 *) V_Res__DM1)
#define V_Res_DM2                    (* (reg8 *) V_Res__DM2) 
/* Input Buffer Disable Override */
#define V_Res_INP_DIS                (* (reg8 *) V_Res__INP_DIS)
/* LCD Common or Segment Drive */
#define V_Res_LCD_COM_SEG            (* (reg8 *) V_Res__LCD_COM_SEG)
/* Enable Segment LCD */
#define V_Res_LCD_EN                 (* (reg8 *) V_Res__LCD_EN)
/* Slew Rate Control */
#define V_Res_SLW                    (* (reg8 *) V_Res__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define V_Res_PRTDSI__CAPS_SEL       (* (reg8 *) V_Res__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define V_Res_PRTDSI__DBL_SYNC_IN    (* (reg8 *) V_Res__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define V_Res_PRTDSI__OE_SEL0        (* (reg8 *) V_Res__PRTDSI__OE_SEL0) 
#define V_Res_PRTDSI__OE_SEL1        (* (reg8 *) V_Res__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define V_Res_PRTDSI__OUT_SEL0       (* (reg8 *) V_Res__PRTDSI__OUT_SEL0) 
#define V_Res_PRTDSI__OUT_SEL1       (* (reg8 *) V_Res__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define V_Res_PRTDSI__SYNC_OUT       (* (reg8 *) V_Res__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(V_Res__SIO_CFG)
    #define V_Res_SIO_HYST_EN        (* (reg8 *) V_Res__SIO_HYST_EN)
    #define V_Res_SIO_REG_HIFREQ     (* (reg8 *) V_Res__SIO_REG_HIFREQ)
    #define V_Res_SIO_CFG            (* (reg8 *) V_Res__SIO_CFG)
    #define V_Res_SIO_DIFF           (* (reg8 *) V_Res__SIO_DIFF)
#endif /* (V_Res__SIO_CFG) */

/* Interrupt Registers */
#if defined(V_Res__INTSTAT)
    #define V_Res_INTSTAT            (* (reg8 *) V_Res__INTSTAT)
    #define V_Res_SNAP               (* (reg8 *) V_Res__SNAP)
    
	#define V_Res_0_INTTYPE_REG 		(* (reg8 *) V_Res__0__INTTYPE)
#endif /* (V_Res__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_V_Res_H */


/* [] END OF FILE */
