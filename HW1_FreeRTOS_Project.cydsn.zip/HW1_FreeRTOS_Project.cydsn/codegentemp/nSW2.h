/*******************************************************************************
* File Name: nSW2.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_nSW2_H) /* Pins nSW2_H */
#define CY_PINS_nSW2_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "nSW2_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 nSW2__PORT == 15 && ((nSW2__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    nSW2_Write(uint8 value);
void    nSW2_SetDriveMode(uint8 mode);
uint8   nSW2_ReadDataReg(void);
uint8   nSW2_Read(void);
void    nSW2_SetInterruptMode(uint16 position, uint16 mode);
uint8   nSW2_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the nSW2_SetDriveMode() function.
     *  @{
     */
        #define nSW2_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define nSW2_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define nSW2_DM_RES_UP          PIN_DM_RES_UP
        #define nSW2_DM_RES_DWN         PIN_DM_RES_DWN
        #define nSW2_DM_OD_LO           PIN_DM_OD_LO
        #define nSW2_DM_OD_HI           PIN_DM_OD_HI
        #define nSW2_DM_STRONG          PIN_DM_STRONG
        #define nSW2_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define nSW2_MASK               nSW2__MASK
#define nSW2_SHIFT              nSW2__SHIFT
#define nSW2_WIDTH              1u

/* Interrupt constants */
#if defined(nSW2__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in nSW2_SetInterruptMode() function.
     *  @{
     */
        #define nSW2_INTR_NONE      (uint16)(0x0000u)
        #define nSW2_INTR_RISING    (uint16)(0x0001u)
        #define nSW2_INTR_FALLING   (uint16)(0x0002u)
        #define nSW2_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define nSW2_INTR_MASK      (0x01u) 
#endif /* (nSW2__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define nSW2_PS                     (* (reg8 *) nSW2__PS)
/* Data Register */
#define nSW2_DR                     (* (reg8 *) nSW2__DR)
/* Port Number */
#define nSW2_PRT_NUM                (* (reg8 *) nSW2__PRT) 
/* Connect to Analog Globals */                                                  
#define nSW2_AG                     (* (reg8 *) nSW2__AG)                       
/* Analog MUX bux enable */
#define nSW2_AMUX                   (* (reg8 *) nSW2__AMUX) 
/* Bidirectional Enable */                                                        
#define nSW2_BIE                    (* (reg8 *) nSW2__BIE)
/* Bit-mask for Aliased Register Access */
#define nSW2_BIT_MASK               (* (reg8 *) nSW2__BIT_MASK)
/* Bypass Enable */
#define nSW2_BYP                    (* (reg8 *) nSW2__BYP)
/* Port wide control signals */                                                   
#define nSW2_CTL                    (* (reg8 *) nSW2__CTL)
/* Drive Modes */
#define nSW2_DM0                    (* (reg8 *) nSW2__DM0) 
#define nSW2_DM1                    (* (reg8 *) nSW2__DM1)
#define nSW2_DM2                    (* (reg8 *) nSW2__DM2) 
/* Input Buffer Disable Override */
#define nSW2_INP_DIS                (* (reg8 *) nSW2__INP_DIS)
/* LCD Common or Segment Drive */
#define nSW2_LCD_COM_SEG            (* (reg8 *) nSW2__LCD_COM_SEG)
/* Enable Segment LCD */
#define nSW2_LCD_EN                 (* (reg8 *) nSW2__LCD_EN)
/* Slew Rate Control */
#define nSW2_SLW                    (* (reg8 *) nSW2__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define nSW2_PRTDSI__CAPS_SEL       (* (reg8 *) nSW2__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define nSW2_PRTDSI__DBL_SYNC_IN    (* (reg8 *) nSW2__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define nSW2_PRTDSI__OE_SEL0        (* (reg8 *) nSW2__PRTDSI__OE_SEL0) 
#define nSW2_PRTDSI__OE_SEL1        (* (reg8 *) nSW2__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define nSW2_PRTDSI__OUT_SEL0       (* (reg8 *) nSW2__PRTDSI__OUT_SEL0) 
#define nSW2_PRTDSI__OUT_SEL1       (* (reg8 *) nSW2__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define nSW2_PRTDSI__SYNC_OUT       (* (reg8 *) nSW2__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(nSW2__SIO_CFG)
    #define nSW2_SIO_HYST_EN        (* (reg8 *) nSW2__SIO_HYST_EN)
    #define nSW2_SIO_REG_HIFREQ     (* (reg8 *) nSW2__SIO_REG_HIFREQ)
    #define nSW2_SIO_CFG            (* (reg8 *) nSW2__SIO_CFG)
    #define nSW2_SIO_DIFF           (* (reg8 *) nSW2__SIO_DIFF)
#endif /* (nSW2__SIO_CFG) */

/* Interrupt Registers */
#if defined(nSW2__INTSTAT)
    #define nSW2_INTSTAT            (* (reg8 *) nSW2__INTSTAT)
    #define nSW2_SNAP               (* (reg8 *) nSW2__SNAP)
    
	#define nSW2_0_INTTYPE_REG 		(* (reg8 *) nSW2__0__INTTYPE)
#endif /* (nSW2__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_nSW2_H */


/* [] END OF FILE */
